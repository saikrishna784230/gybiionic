angular.module('gybi.config', [])
.constant('WORDPRESS_API_URL', 'http://innvectra.com/gybi/wp-json/')
